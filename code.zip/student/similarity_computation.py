import numpy as np

class SimilarityComputation:
    
    def compute_degree_matrices(self, R):
        m, n = R.shape
        # TODO: Implement this method
        pass
    
    def compute_user_similarity_matrix(self, R, P):
        m = R.shape[0]
        # TODO: Implement this method
        pass
    
    def compute_item_similarity_matrix(self, R, Q):
        n = R.shape[1]
        # TODO: Implement this method
        pass